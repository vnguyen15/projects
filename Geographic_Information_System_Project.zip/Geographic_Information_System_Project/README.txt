About:

The project use raw GPS data from regular vehicles to detect intersections in advance to creating roadable map with more
frequently update and less expensive compare to other manually ways that need professional trainned technicians/engineers 
and costly equipments...
-----------------

I.  List of ifiles:

	- 1_traces_map.html : is map ONLY contain GPS traces
	- 2_potential_intersections.html : map contains GPS traces + potential intersections
	- 3_final_intersections.html: map contains GPS traces and final precise intersections after removing fake intersections
	- gps_traces.txt: input GPS traces in format "latitude" and "longitude"
	- potential_Intersections.txt (output): list of potential intersections
	- final_intersections.txt (output after prunning process): list of final intersections
	- intersections.java (source codes) 

II. Running java file: intersections.java
	
	To run it under major editor such as Eclipse, jgrasp:
		- create potential intersections: use the line //intersections.createPotentialIntersections(...) in main method
 		- create the final intersections: use the line  //intersections.pruneIntersection(...) in maind method
	To convert the intersections into Javascript Array use line //intersections.createList4JavaScript (...)