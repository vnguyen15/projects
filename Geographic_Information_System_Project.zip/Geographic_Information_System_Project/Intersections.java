/**
 * TCSS 565 A - GIS
 * Winter 2017
 * Pro. Ali
 * 
 * Group 1: Cheng Li, Aaron, Jowy A Tran, Viet Nguyen
 */

import java.io.BufferedReader;  
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 * The algorithm process input location( latitude and longitude) from GPS traces and find intersections between roads 
 * 
 * @author Group 1: Cheng Li, Aaron, Jowy A Tran, Viet Nguyen
 *
 */
public class Intersections {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Intersections intersections = new Intersections();
	
		//intersections.createPotentialIntersections("gps_traces.txt", "potential_Intersections.txt"); // create potential turning points
		//intersections.pruneIntersection("potential_Intersections.txt", "refine_intersections.txt");
		//intersections.createList4JavaScript ("refine_intersections.txt", "intersection_array.txt" );
		
		//intersections.converttMyTraces("gis3giscom.txt"); // extract lat and lon from my sample traces from MyDatabase format
		// intersections.createCONP("47.456148 -122.169778", "47.456315 -122.169782", "47.456419 -122.170010");		
	}
	
	/**
	 * Check all the potential turning points and see whether there is at least 1 other point that can form a fair of vectors angle 
	 * about 135 to 225 degree, specifically compare 2 vectors P43, and other vector P43' where P4 and p4' are potential points
	 * , P3 and P3' are the other points that belong to its own potential P4 or P4'
	 */
	public void pruneIntersection(String input, String output) {
		try {
			Scanner s = new Scanner(new File(input)); 
			List<String> list = new ArrayList<>();
			while(s.hasNextLine()) {
				String line = s.nextLine();
				list.add(line);
				//System.out.println(line);
			}
			s.close();
			
			for (int i = 0; i < list.size(); i++) {
				Scanner s1 = new Scanner(list.get(i));
				
				String latP4 = s1.next();
				String lonP4 = s1.next();
				String latP1 = s1.next();
				String lonP1 = s1.next();
				
				double latP44 = Double.parseDouble(latP4);
				double lonP44 = Double.parseDouble(lonP4);
				double latP11 = Double.parseDouble(latP1);
				double lonP11 = Double.parseDouble(lonP1);
				s1.close();
				
				// check the rest of other lines start from line i
				for ( int j = i + 1; j < list.size(); j++) {
				
					Scanner s2 = new Scanner(list.get(j));
					
					String nextlatP4 = s2.next();
					String nextLonP4 = s2.next();
					String nextLatP1 = s2.next();
					String nextLonP1 = s2.next();					
					double nextLatP44 = Double.parseDouble(nextlatP4);
					double nextLonP44 = Double.parseDouble(nextLonP4 );
					double nextLatP11 = Double.parseDouble(nextLatP1);
					double nextLonP11 = Double.parseDouble(nextLonP1);
					s2.close();
					
					double distance =  calDist2Points(latP44, nextLatP44, lonP44, nextLonP44);
					if (distance < 15) { // if distance between 2 turning points small, they must belong to the same intersection
						
						//System.out.println(latP4  + " " + lonP4 + " " +  nextlatP4 + " " + nextLonP4 + "\n");
						// only choose 1 point P4, either but not both
						String vector1 = createVector( latP4, lonP4, latP1, lonP1);
						String vector2 = createVector( latP4, lonP4, nextLatP1, nextLonP1);
						double theta = Math.toDegrees(calAngle(vector1 , vector2 ));
						if (theta > 135 && theta < 225 ) { // close to 180 degree if possible, 2 vectors form a line as much as possible 
							// store P4 as final intersection
							try (FileWriter fw = new FileWriter(output, true);
									BufferedWriter bw = new BufferedWriter(fw);
									PrintWriter out = new PrintWriter(bw)) {
									out.print(latP4  + " " + lonP4 + " " +  nextlatP4 + " " + nextLonP4 + "\r\n"); 
									out.flush();
									fw.close();
							} catch (IOException e) {}		
							
							
							break; // break out if found the result, no need to go for the rest of the list
						} 
							
					}			
				}			
			}				
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Processing all the points to find possible / potential intersection
	 * 
	 * @param fileName is list of location in latitude and longitude
	 */
	@SuppressWarnings("resource")
	public void createPotentialIntersections(String input, String output) {
		
		Intersections intersections = new Intersections();
		BufferedReader reader = null;
	    File file = new File(input);
	    String line;
	    try {
	    	reader = new BufferedReader(new FileReader(file));
	    	
	    	String[] arr1 = reader.readLine().split(" "); // get 1st point
			String[] arr2 = reader.readLine().split(" "); // get 2nd point
			Double lat1 = Double.parseDouble(arr1[0]);
			Double lon1 = Double.parseDouble(arr1[1]);
			Double lat2 = Double.parseDouble(arr2[0]);
			Double lon2 = Double.parseDouble(arr2[1]);
			
			int lineNum = 1; // for debug purposes
			while ((line = reader.readLine()) != null ) { // get the 3rd point	
				lineNum++;
				String[] arr3 = reader.readLine().split(" ");
						
				if (arr2 != null && arr3 != null) {					
					// find angle between 2 vectors P01 and P12				
					Double lat3 = Double.parseDouble(arr3[0]);
					Double lon3 = Double.parseDouble(arr3[1]);
					
					// calculate distance between points: P1 to P2 and P2 to P3
					double distP12 = intersections.calDist2Points(lat1, lat2, lon1, lon2);
					double distP23 = intersections.calDist2Points(lat2, lat3, lon2, lon3);
					if (distP12 < 2 && distP23 > 2) { // if 2nd point is the same as 1st point
						lat2 = lat3;
						lon2 = lon3;
						
					} else if (distP12 > 2 && distP23 > 35 ) { // start over , assign P3 as starting point, and need P2
						lat1 = lat3;
						lon1 = lon3;
						if ((line = reader.readLine()) != null) { // need P2
							String[] arrP2 = reader.readLine().split(" "); // get 2nd point
							lat2 = Double.parseDouble(arrP2[0]);
							lon2 = Double.parseDouble(arrP2[1]);
						}
							

					} else if (distP12 > 2 && distP23 > 2 && distP23 < 35) { // if 3 points are separated by a distance of 2meter or more
						
						//if (distP23 > )
						// create 2 vectors
						arr1[0] = lat1+"";
						arr1[1] = lon1+"";
						arr2[0] = lat2+"";
						arr2[1] = lon2+"";
						String vector1 = intersections.createVector(arr1[0], arr1[1], arr2[0], arr2[1]);
						String vector2 = intersections.createVector(arr2[0], arr2[1], arr3[0], arr3[1]);
						double theta = Math.toDegrees(intersections.calAngle(vector1 , vector2));
						
					//	System.out.println(theta);
						if (0 < theta && theta < 10 ) { // check whether all points are on the same straight line
							// update the last 2 points
							lat1 = lat2;
							lon1 = lon2;
							lat2 = lat3;
							lon2 = lon3;
						}
						
						else if (theta > 25 ) {
							String p1 = lat1+" "+lon1;
							String p2 = lat2+" "+lon2;
							String p3 = lat3+" "+lon3;			
							intersections.createCONP(p1, p2, p3, output);
							
							// start finding new turning point by update P0 and P1 if there are at least 3 more points
							// then update the current P1, P2, and P3 if possible
							String nextLine1, nextLine2;
							if ( (nextLine1 = reader.readLine()) != null &&  (nextLine2 = reader.readLine()) != null) {
								String[] nextArr1 = nextLine1.split(" "); // get next 1st point
								String[] nextArr2 = nextLine2.split(" "); // get next 2nd point
								lat1 = Double.parseDouble(nextArr1[0]);
								lon1 = Double.parseDouble(nextArr1[1]);
								lat2 = Double.parseDouble(nextArr2[0]);
								lon2 = Double.parseDouble(nextArr2[1]);
							}							
						}
					}
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// calculate Potential intersection / Converging point in latitude and longitude then store the point in the file if 
	// there is exist an angle at least 45 degree
	// input String point (lat lon)
	public boolean createCONP (String point1, String point2, String point3, String output) {
		Intersections intersections = new Intersections();
		String[] arr1 = point1.split(" ");
		String[] arr2 = point2.split(" ");
		String[] arr3 = point3.split(" ");
		
		Double lat1 = Double.parseDouble(arr1[0]);
		Double lon1 = Double.parseDouble(arr1[1]);
		Double lat2 = Double.parseDouble(arr2[0]);
		Double lon2 = Double.parseDouble(arr2[1]);
		Double lat3 = Double.parseDouble(arr3[0]);
		Double lon3 = Double.parseDouble(arr3[1]);
		double distance = intersections.calDistLanLon(lat2, lat3, lon2, lon3);
		
		String vector1 = intersections.createVector(arr1[0], arr1[1], arr2[0], arr2[1]);
		String vector2 = intersections.createVector(arr2[0], arr2[1], arr3[0], arr3[1]);
		double theta = intersections.calAngle(vector1 , vector2);

		if (Math.toDegrees(theta) < 25){

			return false;}
		
		double p1p4 = Math.cos(theta) * distance;
		// calculate longitude of P4
		double lon4 = 0;
		if (lon2 > lon1) {
			lon4 = p1p4 * Math.sqrt(1 / (1 + Math.pow((lat2-lat1) / (lon2-lon1), 2)  )) + lon2;
			
		} else {
			lon4 = p1p4 * ( - Math.sqrt(1 / (1 + Math.pow((lat2-lat1) / (lon2-lon1), 2)  ))) + lon2;
		}
		
		// calculate longitude of P4
		double lat4 = 0;
		if (lat2 > lat1) {
			lat4 = lat2 + p1p4 * Math.sqrt(1 / (1 + Math.pow((lat2-lat1) / (lon2-lon1), 2)  )) * Math.abs((lat2 - lat1) / (lon2 - lon1));
			
		} else {
			lat4 = lat2 - p1p4 * ( Math.sqrt(1 / (1 + Math.pow((lat2-lat1) / (lon2-lon1), 2)  ))) * Math.abs((lat2 - lat1) / (lon2 - lon1));
		}

		// store the Converging point P4 into a file and also P3 for later confirm ( by create vector P3 with converging point P4)
		//seattleOut += (lat4 + " " + lon4 + " " +  point3 + "\r\n");
		//System.out.println(seattleOut);
		//convergingPoints.append(lat4 + " " + lon4 + " " +  point3 + "\r\n");
		//System.out.println("converging Point: " + lat4 + " " + lon4 + " " +  point3);
		try (FileWriter fw = new FileWriter(output, true); //"convergPoints2.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
				out.print(lat4 + " " + lon4 + " " +  point3 + "\r\n"); 
				out.flush();
				
		} catch (IOException e) {
		}		
	
		return true;
	}
	
	
	/**
	 * convert locations to array of location in Latitude and Longitude format in JavaScript form to display on google map 
	 *  
	 * @param fileName
	 */
	public void createList4JavaScript (String input, String output ) {
		
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = null;
	    File file = new File(input); //convergPoints2.txt");
	    try {
			reader = new BufferedReader(new FileReader(file));
			String line;
			int lineNum = 1;
		    while ((line = reader.readLine()) != null) {   
		    	//System.out.print(lineNum);
		    			
					String[] arr = line.split(" ");
					String lineOut = "['P" + lineNum + "', " + arr[0] + ", " + arr[1] + "],\r\n";
					sb.append(lineOut);
					lineNum++;
				
					
		    }
		    try (FileWriter fw = new FileWriter(output, true);
		    		BufferedWriter bw = new BufferedWriter(fw);
		    		PrintWriter out = new PrintWriter(bw)) {				
					out.println(sb.toString());
					out.flush();
			}
		    
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	    				
	}
	
	
	// extract lat and lon from my sample traces
	public void extractMyTraces() {
		BufferedReader reader = null;

	    File file = new File("convergPoints2.txt");
	    try {
			reader = new BufferedReader(new FileReader(file));
			String line;
			int lineNum = 1;
		    while ((line = reader.readLine()) != null) {   
			
		    	try (FileWriter fw = new FileWriter("convergPoints22.txt", true);
		    		BufferedWriter bw = new BufferedWriter(fw);
		    		PrintWriter out = new PrintWriter(bw)) {
		    		String lat="", lon="";
		    		int index = 0;
		    		for (int  i = 1; i < line.length(); i++) {
		    			String currentChar = line.charAt(i) + "";
		    			if(!currentChar.equals("|")) {
		    				lat+= line.charAt(i);
		    				index = i;
		    				
		    			} else {
		    				index++;
		    				break;
		    			}
		    		}
		    		for (int i = index+1 ; i < line.length(); i++) {
		    			
		    			lon+= line.charAt(i);
		    		}
		    		
					//String[] arr = line.split("|");
					String lineOut = "['P" + lineNum + "', " + lat + ", " + lon + "],";
					out.println(lineOut);
					out.flush();
					lineNum++;
				}
					
		    }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// extract lat and lon from my traces from MyDatabase 
	public void converttMyTraces(String fileName) {
			BufferedReader reader = null;

		    File file = new File(fileName);
		    try {
				reader = new BufferedReader(new FileReader(file));
				String line;
				int lineNum = 1;
			    while ((line = reader.readLine()) != null) {   
				
			    	try (FileWriter fw = new FileWriter("lanlong_gis_3.txt", true);
			    		BufferedWriter bw = new BufferedWriter(fw);
			    		PrintWriter out = new PrintWriter(bw)) {
			    		String lat="", lon="";
			    		int index = 0;
			    		for (int  i = 1; i < line.length(); i++) {
			    			String currentChar = line.charAt(i) + "";
			    			if(!currentChar.equals("|")) {
			    				lat+= line.charAt(i);
			    				index = i;
			    				
			    			} else {
			    				index++;
			    				break;
			    			}
			    		}
			    		for (int i = index+1 ; i < line.length(); i++) {
			    			
			    			lon+= line.charAt(i);
			    		}
			    		
/*						String[] arr = line.split("|");
						lat = arr[1];
						lon = arr[2];*/
						String lineOut = lat + " " + lon;
						out.println(lineOut);
						out.flush();
						lineNum++;
					}
						
			    }
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
	// extract latitude and longitude from original GPX public file from OpenStreetMap
		public void extracLatLon(String fileName) {
			
			StringBuilder output = new StringBuilder();
			
			BufferedReader reader = null;
		    File file = new File(fileName);
		    try {
				reader = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		    String line;
		    try {
				while ((line = reader.readLine()) != null && !line.equals("</gpx>")) {
					
					String lat = "";
					String lon = "";
					if (line.contains("lat=")) {
						String[] arr = line.split(" ");
						for (int i = 0; i < arr.length; i++) {
							if (arr[i].contains("lat")) 
								lat = arr[i];
							if (arr[i].contains("lon")) 
								lon = arr[i];
						}
					    int index= 0;
					    String testLat = "";
					    while (!Character.isDigit(lat.charAt(index))) {
					    	if (lat.charAt(index) == '-')
					    		break;
					    	index++;
					    }
					    
					    while (Character.isDigit(lat.charAt(index)) || lat.charAt(index) == '.' || lat.charAt(index) == '-') {
					    	
					    	testLat += lat.charAt(index);
					    	index++;
					    }
					    
					    //////////
					    int index1= 0;
					    String testLat1 = "";
					    while (!Character.isDigit(lon.charAt(index1))) {
					    	if (lon.charAt(index1) == '-')
					    		break;
					    	index1++;
					    }
					    
					    while (Character.isDigit(lon.charAt(index1)) || lon.charAt(index1) == '.' || lon.charAt(index1) == '-') {
					    	
					    	testLat1 += lon.charAt(index1);
					    	index1++;
					    }
					    
					    output.append(testLat + " " + testLat1 + "\r\n");
					}		
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		    try (FileWriter fw = new FileWriter("seattle_latLon.txt", true);
					BufferedWriter bw = new BufferedWriter(fw);
					PrintWriter out = new PrintWriter(bw)) {
				out.println(output.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		// calculate distance of 2 point in latitude and longitude
	public Double calDistLanLon (double lat1, double lat2, double lon1, double lon2) {
		
		return (double) Math.sqrt((lat2 - lat1) * (lat2 - lat1) +  (lon2 - lon1) * (lon2 - lon1));
	}
		
		// find angle between 2 vectors
	public double calAngle(String vec1, String vec2) {
			
			String[] arr1 = vec1.split(",");
			String[] arr2 = vec2.split(",");
			double vec1X = Double.parseDouble(arr1[0]);
			double vec1Y = Double.parseDouble(arr1[1]);
			
			double vec2X = Double.parseDouble(arr2[0]);
			double vec2Y = Double.parseDouble(arr2[1]);
			
			double dotProduct = vec1X * vec2X + (vec1Y * vec2Y);
			double magnitude1 = Math.sqrt(vec1X * vec1X + (vec1Y * vec1Y));
			double magnitude2 = Math.sqrt(vec2X * vec2X + (vec2Y * vec2Y));
			double cosTheta = dotProduct / (magnitude1 * magnitude2);
			
			double theta = Math.acos(cosTheta);
			
			return theta;
			
	}
		
	// create a vector from 2 points
	public String createVector(String lat1, String lon1, String lat2, String lon2) {
			
		String vector = "";
		vector = (Double.parseDouble(lat2) - Double.parseDouble(lat1)) + "," + (Double.parseDouble(lon2) - Double.parseDouble(lon1));		
			
		return vector;
			
	}
		
	// Return distance in Meter between to locations
	public double calDist2Points(double x1, double x2, double y1, double y2) {
			
			double R = 6371e3; // metres
			double latR1 = toRadians(x1);
			double latR2= toRadians(x2);
			double difLat = toRadians(x2-x1);
			double difLon = toRadians(y2-y1);

			double a = Math.sin(difLat/2) * Math.sin(difLat/2) +
			        Math.cos(latR1) * Math.cos(latR2) *
			        Math.sin(difLon/2) * Math.sin(difLon/2);
			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

			double d = R * c; // distance between 2 points
			
			return d;
			
	}
		
	// convert latitude and longitude to radians
	private double toRadians(double latlon) {
			
			double radian;
			
			radian = latlon * Math.PI / 180;
			
			return radian;
	}
	
	public void extractIntersection() {
		Intersections intersections = new Intersections();
		BufferedReader reader = null;
	    File file = new File("latLon.txt");
	    try {
			reader = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	    String line;
	    
	    try {
	    	line = reader.readLine(); // read 1st line
	    	String[] arr1 = line.split(" ");
	    	// current point
	    	String lat1 = arr1[0];
	    	String lon1 = arr1[1];
	    	
			while ((line = reader.readLine()) != null ) { // the other lines
				String[] arr2 = line.split(" ");
				
				// next point
		    	String lat2 = arr2[0];
		    	String lon2 = arr2[1];
		    	String currentVector = "";
		    	// compare distance between 2 points with a range from 2 meter to 25 meter
		    	Double distance2Points = intersections.calDist2Points(Double.parseDouble(lat1), Double.parseDouble(lat2), Double.parseDouble(lon1), Double.parseDouble(lon2));
		    	if (distance2Points > 2 && distance2Points < 35) {
		    	
		    		currentVector = intersections.createVector(lat1, lon1, lat2, lon2);
		    		System.out.println(currentVector);
		    	}
		    		
		    	System.out.println(distance2Points);
		    	lat1 = lat2;
		    	lon1 = lon2;
		    	
		    	// P3
		    	line = reader.readLine();
		    	String[] arr3 = line.split(" ");
				
				// next point
		    	String lat3 = arr3[0];
		    	String lon3 = arr3[1];
		    	String currentVector1 = "";
		    	Double distance2Points1 = intersections.calDist2Points(Double.parseDouble(lat2), Double.parseDouble(lat3), Double.parseDouble(lon2), Double.parseDouble(lon3));
		    	if (distance2Points1 > 2 && distance2Points1 < 35) {
			    	
		    		currentVector1 = intersections.createVector(lat2, lon2, lat3, lon3);
		    		System.out.println("Distance P2 to P3 " + distance2Points1 + " Vector 2 - " +currentVector1);
		    	}
		    	
		    	System.out.println(Math.toDegrees(intersections.calAngle(currentVector, currentVector1)));
		    	break;
			}
			
	    } catch (IOException e) {
			e.printStackTrace();
		}
		
	}
		
}


